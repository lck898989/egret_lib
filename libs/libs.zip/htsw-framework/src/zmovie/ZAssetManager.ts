/**
 * Created by zringhost on 14-12-14.
 */
namespace zmovie {
    export class ZAssetManager {
        public constructor() {

        }
    }
}
