class SceneInfo {
    public classFactory: any;
    public resName: string;
    public data: Object;
    public animType: number;
    constructor() {
        this.classFactory = null;
        this.resName = "";
        this.data = null;
        this.animType = 0;
    }
}
