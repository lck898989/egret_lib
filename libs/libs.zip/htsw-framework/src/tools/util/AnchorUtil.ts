/**
 * 该工具类用于解决EgretEngine2.5版本没有anchorX/anchorY属性值的问题
 * 在创建游戏场景前需要执行AnchorUtil.init();初始化工具并完成属性的注入
 * 方式一（推荐）：
 * AnchorUtil.setAnchorX(target, anchorX); //设置对象的anchorX值
 * AnchorUtil.setAnchorY(target, anchorY); //设置对象的anchorY值
 * AnchorUtil.setAnchor(target, anchor); //同时设置对象的anchorX和anchorY值
 * 方式二：
 * target["anchorX"] = value; //设置对象的anchorX值
 * target["anchorY"] = value; //设置对象的anchorY值
 * target["anchor"] = value; //同时设置对象的anchorX和anchorY值
 * 方式三：
 * 修改egret.d.ts，在DisplayObject声明中添加anchorX、anchorY和anchor属性，代码的写法和引擎之前版本相同：
 * target.anchorX = value; //设置对象的anchorX值
 * target.anchorY = value; //设置对象的anchorY值
 * target.anchor = value; //同时设置对象的anchorX和anchorY值
 *
 * Created by Saco on 2015/9/16.
 */
class AnchorUtil {
    /**
     * 初始化工具类，并完成注入anchorX/anchorY属性
     */
    public static init(): void {
        if (this._isInited) { return; }
        this._propertyChange = Object.create(null);
        this._anchorChange = Object.create(null);
        this.injectAnchor();
        this._isInited = true;
    }

    /**
     * 设置对象的anchorX值
     * @param target 被设置相对冒点属性的对象
     * @param value 相对锚点值
     */
    public static setAnchorX(target: egret.DisplayObject, value: number): void {
        target["anchorX"] = value;
    }

    /**
     * 设置对象的anchorY值
     * @param target 被设置相对冒点属性的对象
     * @param value 相对锚点值
     */
    public static setAnchorY(target: egret.DisplayObject, value: number): void {
        target["anchorY"] = value;
    }

    /**
     * 设置对象的anchor值，同时改变anchorX和anchorY值
     * @param target 被设置相对冒点属性的对象
     * @param value 相对锚点值
     */
    public static setAnchor(target: egret.DisplayObject, value: number): void {
        target["anchorX"] = target["anchorY"] = value;
    }

    /**
     * 获得对象的anchorX值
     * @param target 取值的对象
     * @returns {any|number} anchorX值
     */
    public static getAnchorX(target: egret.DisplayObject): number {
        return target["anchorX"] || 0;
        // return 0;
    }

    /**
     * 获得对象的anchorY值
     * @param target 取值的对象
     * @returns {any|number} anchorY值
     */
    public static getAnchorY(target: egret.DisplayObject): number {
        return target["anchorY"] || 0;
      //  return 0;
    }

    private static _isInited;
    private static _propertyChange: any;
    private static _anchorChange: any;

    /**
     * 注入anchorX/anchorY属性，并重写引擎底层方法实现相对锚点
     */
    private static injectAnchor(): void {
        Object.defineProperty(egret.DisplayObject.prototype, "width", {
            get() {
                return this.$getWidth();
            },
            set(value) {
                this.$setWidth(value);
                AnchorUtil._propertyChange[this.hashCode] = true;
                egret.callLater(() => {
                    AnchorUtil.changeAnchor(this);
                },              this);
            },
            enumerable: true,
            configurable: true,
        });

        Object.defineProperty(egret.DisplayObject.prototype, "height", {
            get() {
                return this.$getHeight();
            },
            set(value) {
                this.$setHeight(value);
                AnchorUtil._propertyChange[this.hashCode] = true;
                egret.callLater(() => {
                    AnchorUtil.changeAnchor(this);
                },              this);
            },
            enumerable: true,
            configurable: true,
        });

        Object.defineProperty(egret.DisplayObject.prototype, "anchorX", {
            get() {
                return this["_anchorX"];
            },
            set(value) {
                this._anchorX = value;
                AnchorUtil._propertyChange[this.hashCode] = true;
                AnchorUtil._anchorChange[this.hashCode] = true;
                egret.callLater(() => {
                    AnchorUtil.changeAnchor(this);
                },              this);
            },
            enumerable: true,
            configurable: true,
        });

        Object.defineProperty(egret.DisplayObject.prototype, "anchorY", {
            get() {
                return this["_anchorY"];
            },
            set(value) {
                this._anchorY = value;
                AnchorUtil._propertyChange[this.hashCode] = true;
                AnchorUtil._anchorChange[this.hashCode] = true;
                egret.callLater(() => {
                    AnchorUtil.changeAnchor(this);
                },              this);
            },
            enumerable: true,
            configurable: true,
        });

        Object.defineProperty(egret.DisplayObject.prototype, "anchor", {
            get() {
                return this["_anchorX"];
            },
            set(value) {
                this._anchorX = value;
                this._anchorY = value;
                AnchorUtil._propertyChange[this.hashCode] = true;
                AnchorUtil._anchorChange[this.hashCode] = true;
                egret.callLater(() => {
                    AnchorUtil.changeAnchor(this);
                },              this);
            },
            enumerable: true,
            configurable: true,
        });

        if (eui && eui.Component) {
            Object.defineProperty(eui.Component.prototype, "width", {
                get() {
                    return this._UIC_Props_._uiWidth;
                },
                set(value) {
                    this.$setWidth(value);
                    AnchorUtil._propertyChange[this.hashCode] = true;
                    egret.callLater(() => {
                        AnchorUtil.changeAnchor(this);
                    },              this);
                },
                enumerable: true,
                configurable: true,
            });

            Object.defineProperty(eui.Component.prototype, "height", {
                get() {
                    return this._UIC_Props_._uiHeight;
                },
                set(value) {
                    this.$setHeight(value);
                    AnchorUtil._propertyChange[this.hashCode] = true;
                    egret.callLater(() => {
                        AnchorUtil.changeAnchor(this);
                    },              this);
                },
                enumerable: true,
                configurable: true,
            });

            eui.Component.prototype.setMeasuredSize = function(w: number, h: number) {
                let change: boolean = false;
                if (this._UIC_Props_._uiWidth != w) {
                    this._UIC_Props_._uiWidth = w;
                    change = true;
                }
                if (this._UIC_Props_._uiHeight != h) {
                    this._UIC_Props_._uiHeight = h;
                    change = true;
                }
                if (change) {
                    this.invalidateDisplayList();
                    this.dispatchResizeEvent();
                    AnchorUtil._propertyChange[this.hashCode] = true;
                    egret.callLater(() => {
                        AnchorUtil.changeAnchor(this);
                    },              this);
                }
            };
        }
    }

    private static changeAnchor(tar: any): void {
        if (AnchorUtil._propertyChange[tar.hashCode] && AnchorUtil._anchorChange[tar.hashCode]) {
            tar.anchorOffsetX = tar._anchorX * tar.width;
            tar.anchorOffsetY = tar._anchorY * tar.height;
            delete AnchorUtil._propertyChange[tar.hashCode];
        }
    }
}
