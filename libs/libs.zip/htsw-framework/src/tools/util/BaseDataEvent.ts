class BaseDataEvent extends egret.Event {

    public data: any;

}
