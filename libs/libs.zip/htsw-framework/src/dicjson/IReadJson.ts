﻿/*
  * 所有json数据管理类的借口
  */
interface IReadJson {
    initFromJson(name: string): void;
}
