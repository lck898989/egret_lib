class BaseDefines {

    public static TKCLOUD_TYPE = {
        TO_PAGE : "tky_topage",
    };

    public static VIEW_TYPE = {
        SHOW_WAIT : "show_wait",
        HIDE_WAIT : "hide_wait",
    };

    public static FrameworkVersion: number = 18;
}
