declare class ClassOverScene_Skin extends eui.Skin{
}
declare class ClassSumUpScene_Skin extends eui.Skin{
}
declare class Dlg_CommonMovie_Skin extends eui.Skin{
}
declare class Scene_Loading_Skin extends eui.Skin{
}
declare class Page1Scene_Skin extends eui.Skin{
}
declare class Page2Scene_Skin extends eui.Skin{
}
declare class Page3Scene_Skin extends eui.Skin{
}
declare class Page4Scene_Skin extends eui.Skin{
}
declare class Page5Scene_Skin extends eui.Skin{
}
