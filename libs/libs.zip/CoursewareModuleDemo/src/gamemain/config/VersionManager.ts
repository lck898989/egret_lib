/*
  * 版本配置文件
  */
class VersionManager {

    public static courseware_name:string = "courseware_二年级正课4月份第八讲周期问题下";
    public static VERSION = "0.0.1";
}
