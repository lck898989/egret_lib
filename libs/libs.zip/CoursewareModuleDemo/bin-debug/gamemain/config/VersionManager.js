var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
/*
  * 版本配置文件
  */
var VersionManager = (function () {
    function VersionManager() {
    }
    VersionManager.courseware_name = "courseware_二年级正课4月份第八讲周期问题下";
    VersionManager.VERSION = "0.0.1";
    return VersionManager;
}());
__reflect(VersionManager.prototype, "VersionManager");
