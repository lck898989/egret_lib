declare class Moudle_Page10Scene_Skin extends eui.Skin{
}
declare class Moudle_Page11Scene_Skin extends eui.Skin{
}
declare class Moudle_Page12Scene_Skin extends eui.Skin{
}
declare class Moudle_Page13Scene_Skin extends eui.Skin{
}
declare class Moudle_Page14Scene_Skin extends eui.Skin{
}
declare class Moudle_Page15Scene_Skin extends eui.Skin{
}
declare class Moudle_Page16Scene_Skin extends eui.Skin{
}
declare class Moudle_Page1Scene_Skin extends eui.Skin{
}
declare class Moudle_Page2Scene_Skin extends eui.Skin{
}
declare class Moudle_Page3Scene_Skin extends eui.Skin{
}
declare class Moudle_Page4Scene_Skin extends eui.Skin{
}
declare class Moudle_Page5Scene_Skin extends eui.Skin{
}
declare class Moudle_Page6Scene_Skin extends eui.Skin{
}
declare class Moudle_Page7Scene_Skin extends eui.Skin{
}
declare class Moudle_Page8Scene_Skin extends eui.Skin{
}
declare class Moudle_Page9Scene_Skin extends eui.Skin{
}
declare class ClassOverScene_Skin extends eui.Skin{
}
declare class ClassSumUpScene_Skin extends eui.Skin{
}
declare class Dlg_CommonMovie_Skin extends eui.Skin{
}
declare class DolphinIsland_Skin extends eui.Skin{
}
