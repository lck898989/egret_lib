declare class GetStarScene_Skin extends eui.Skin{
}
declare class CommonButton_Skin extends eui.Skin{
}
declare class Dlg_CommonMovie_Skin extends eui.Skin{
}
