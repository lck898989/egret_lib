/*
  * 版本配置文件
  */
class CoursewareVersion {

    public static courseware_name: string = "courseware_测试";
    public static VERSION = "0.0.1";
}
