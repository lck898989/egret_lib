/*
  * 版本配置文件
  */
class CoursewareVersion {

    public static courseware_name:string = "1年级12月份正课第3讲树阵图之谜上";
    public static VERSION = "0.0.1";
}
