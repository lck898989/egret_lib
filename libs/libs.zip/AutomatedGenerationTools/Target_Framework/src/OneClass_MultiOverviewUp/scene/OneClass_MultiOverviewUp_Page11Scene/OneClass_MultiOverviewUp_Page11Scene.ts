class OneClass_MultiOverviewUp_Page11Scene extends UIObject {

    static key:string = "OneClass_MultiOverviewUp_Page11Scene";

    public constructor() {
        super();
        this.skinName = "OneClass_MultiOverviewUp_Page11Scene_Skin";
    }

    /** 每次进入 */
    public onAdd(): void {

    }

    /** 这里进行移出场景的处理 **/
    public onDestroy(): void {

    }
}
