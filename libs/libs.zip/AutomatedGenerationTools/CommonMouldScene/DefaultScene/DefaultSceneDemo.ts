class DefaultSceneDemo extends UIObject {

    public static key: string = "Page4Scene";

    public constructor() {
        super();
        this.skinName = "Page4Scene_Skin";
    }

    /** 每次进入 */
    public onAdd(): void {

    }

    /** 这里进行移出场景的处理 **/
    public onDestroy(): void {

    }
}
